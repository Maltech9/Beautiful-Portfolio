using System;

namespace WinformaExample
{
    //This is the main form with which the user interacts with. Its functionality is to set the communicating IP to communicate with via TCP. 
    //To test this, place an accessible IP in the IP box, and watch the messages be sent and retrieved. Of you wish to see it is not smoke and mirrors
    //Just set the IP to something invalid


    //Willie Malveaux 12/4/2023
    public partial class Form1 : Form
    {
        P2PChat chat;
        public Form1()
        {
            InitializeComponent();
            KeyPreview = true;
            this.KeyPress += new KeyPressEventHandler(Form1_KeyPress);
            colorDialog1.Color = Color.Red;
            chat = new P2PChat(this);
            chat.StartServer(3000); // Use any port number you prefer, but it will be internal
        }


        //On enter, we will submit a message to the chat
        private void Form1_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Sending logic here
            if (e.KeyChar == (char)13)
            {
                SendButton.PerformClick();
            }
        }

        private void SendButton_Click(object sender, EventArgs e)
        {
            string name = NameBox.Text;
            string color = ColorTranslator.ToHtml(colorDialog1.Color);
            string message = PreviewTextBox.Text;

            chat.SendMessage(ipBox.Text, 3000, name, color, message); // Sending with actual IP and port
            PreviewTextBox.Clear();
        }

        //We need color to make this whole project not so drab
        private void AppendTextWithColor(string text, Color color)
        {
            int start = MainChat.TextLength;
            MainChat.AppendText(text);
            MainChat.Select(start, text.Length);
            MainChat.SelectionColor = color;
            MainChat.SelectionStart = MainChat.TextLength;
            MainChat.SelectionColor = MainChat.ForeColor;
        }


        //This triggers to allow the user to select their own color
        private void PickColor_Click(object sender, EventArgs e)
        {
            colorDialog1.ShowDialog();
        }

        //This is how the chat box stays updatesd. We will append new messages here. 
        public void UpdateChat(ChatMessage msg)
        {
            if (InvokeRequired)
            {
                Invoke(new Action<ChatMessage>(UpdateChat), msg);
                return;
            }

            AppendTextWithColor(msg.Name + ": ", ColorTranslator.FromHtml(msg.Color));
            AppendTextWithColor(msg.Message + Environment.NewLine, Color.Black);
        }

        private void MainChat_TextChanged(object sender, EventArgs e)
        {

        }
    }
}