﻿using System;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using Microsoft.VisualBasic;
using Newtonsoft.Json;
using WinformaExample;

//This code handles the peer to peer notworking and messages

public class ChatMessage
{
    public string Name { get; set; }
    public string Color { get; set; }
    public string Message { get; set; }
}


public class P2PChat
{
    private TcpListener tcpListener;
    private Thread listenThread;

    private Form1 mainForm; // Reference to the main form

    public P2PChat(Form1 form)
    {
        this.mainForm = form;
    }

    public void StartServer(int port)
    {
        this.tcpListener = new TcpListener(IPAddress.Any, port);
        this.listenThread = new Thread(new ThreadStart(ListenForClients));
        this.listenThread.Start();
    }

    private void ListenForClients()
    {
        this.tcpListener.Start();

        while (true)
        {
            // Blocks until a client has connected to the server
            TcpClient client = this.tcpListener.AcceptTcpClient();

            // Create a thread to handle communication with connected client
            Thread clientThread = new Thread(new ParameterizedThreadStart(HandleClientComm));
            clientThread.Start(client);
        }
    }

    private void HandleClientComm(object client)
    {
        TcpClient tcpClient = (TcpClient)client;
        NetworkStream clientStream = tcpClient.GetStream();
        StreamReader reader = new StreamReader(clientStream);

        try
        {
            while (true)
            {
                string json = reader.ReadLine();
                if (json != null)
                {
                    ChatMessage msg = JsonConvert.DeserializeObject<ChatMessage>(json);
                    // Invoke the update method on the UI thread
                    mainForm.UpdateChat(msg); // Assuming 'MainForm' is your form's class name
                }
            }
        }
        catch
        {
            // Handle exceptions...
        }
        finally
        {
            tcpClient.Close();
        }
    }


    public void SendMessage(string ipAddress, int port, string name, string color, string message)
    {
        TcpClient client = new TcpClient();
        
        bool connected = ConnectWithTimeout(client, ipAddress, port, 10000);

        if (!connected) return;

        ChatMessage msg = new ChatMessage
        {
            Name = name,
            Color = color,
            Message = message
        };

        string json = JsonConvert.SerializeObject(msg);

        NetworkStream clientStream = client.GetStream();
        StreamWriter writer = new StreamWriter(clientStream);
        writer.WriteLine(json);
        writer.Flush();
        client.Close();
    }

    //I once scratched my head for months watching a TCP connection crash a program over and over again. 
    //Windows does NOT make these things with timouts by default so we need to implement some ourselves
    public bool ConnectWithTimeout(TcpClient client, string host, int port, int timeout)
    {
        IAsyncResult ar = client.BeginConnect(host, port, null, null);
        WaitHandle wh = ar.AsyncWaitHandle;
        try
        {
            if (!ar.AsyncWaitHandle.WaitOne(TimeSpan.FromMilliseconds(timeout), false))
            {
                client.Close();
              //  throw new TimeoutException("TimeOut Exception");
                MessageBox.Show("Operation has timed out", "Host unavailable",   MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            //client.EndConnect(ar);
            return client.Connected;
        }
        finally
        {
            wh.Close();
        }
    }
}
