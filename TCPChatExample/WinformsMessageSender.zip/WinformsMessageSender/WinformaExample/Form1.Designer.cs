﻿namespace WinformaExample
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            MainChat = new RichTextBox();
            SendButton = new Button();
            PreviewTextBox = new TextBox();
            ipBox = new TextBox();
            NameBox = new TextBox();
            colorDialog1 = new ColorDialog();
            PickColor = new Button();
            SuspendLayout();
            // 
            // MainChat
            // 
            MainChat.Location = new Point(243, 29);
            MainChat.Name = "MainChat";
            MainChat.ReadOnly = true;
            MainChat.Size = new Size(281, 478);
            MainChat.TabIndex = 0;
            MainChat.Text = "";
            MainChat.TextChanged += MainChat_TextChanged;
            // 
            // SendButton
            // 
            SendButton.Location = new Point(449, 513);
            SendButton.Name = "SendButton";
            SendButton.Size = new Size(75, 23);
            SendButton.TabIndex = 1;
            SendButton.Text = "Send";
            SendButton.UseVisualStyleBackColor = true;
            SendButton.Click += SendButton_Click;
            // 
            // PreviewTextBox
            // 
            PreviewTextBox.Location = new Point(243, 514);
            PreviewTextBox.Name = "PreviewTextBox";
            PreviewTextBox.Size = new Size(200, 23);
            PreviewTextBox.TabIndex = 2;
            // 
            // ipBox
            // 
            ipBox.Location = new Point(12, 29);
            ipBox.Name = "ipBox";
            ipBox.Size = new Size(197, 23);
            ipBox.TabIndex = 3;
            ipBox.Text = "192.168.6.113";
            // 
            // NameBox
            // 
            NameBox.Location = new Point(12, 446);
            NameBox.Name = "NameBox";
            NameBox.Size = new Size(197, 23);
            NameBox.TabIndex = 4;
            NameBox.Text = "Name";
            // 
            // PickColor
            // 
            PickColor.Location = new Point(134, 475);
            PickColor.Name = "PickColor";
            PickColor.Size = new Size(75, 23);
            PickColor.TabIndex = 5;
            PickColor.Text = "Color";
            PickColor.UseVisualStyleBackColor = true;
            PickColor.Click += PickColor_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(550, 566);
            Controls.Add(PickColor);
            Controls.Add(NameBox);
            Controls.Add(ipBox);
            Controls.Add(PreviewTextBox);
            Controls.Add(SendButton);
            Controls.Add(MainChat);
            Name = "Form1";
            Text = "Local Chat";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private RichTextBox MainChat;
        private Button SendButton;
        private TextBox PreviewTextBox;
        private TextBox ipBox;
        private TextBox NameBox;
        private ColorDialog colorDialog1;
        private Button PickColor;
    }
}